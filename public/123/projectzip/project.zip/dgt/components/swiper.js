import Swiper from './Swiper/Swiper.js'
module.exports = Swiper