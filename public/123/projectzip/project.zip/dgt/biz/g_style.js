import {StyleSheet} from 'react-native';
module.exports= StyleSheet.create({
  font:{
      fontSize:24,
      color: 'white',
      marginTop:20,
  },
  header: {
    height:80,
       justifyContent: 'center',
        alignItems: 'center',
        
    backgroundColor: '#FF5658',
  }
});